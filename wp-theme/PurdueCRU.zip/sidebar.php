		<div class="hide-600">
			<span class="r">
				<?php cru_social_icon_widget(); ?>
			</span>
		</div> <!-- end of .hide-600 -->
		<?php
		cru_events_widget("PurdueCru");
		cru_twitter_widget();
		?>
		
