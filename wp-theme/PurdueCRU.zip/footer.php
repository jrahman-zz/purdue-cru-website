	</div> <!-- end of .content -->	
	<!-- Start of the footer -->
	<div id="footer">
		<div id="footer-wrapper">
			<div class="footer-item">
				<div id="top-button" class="footer-item show-600">
					<a id="top-link" href="#top">
						<img width="60" height="40" src="<?php echo get_template_directory_uri()?>/images/top_arrow.gif">					
					</a>
				</div>
				<div class="footer-item">
				© 2013 Purdue CRU
				</div>
			</div>
		</div> <!-- end of #footer-wrapper -->
	</div> <!-- end of #footer -->
<?php wp_footer(); ?>
</body>
</html>
