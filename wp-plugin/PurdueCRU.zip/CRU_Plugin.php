<?php


/*
Plugin Name: Purdue CRU Wordpress Plugin
Description: Plugin for managing Purdue CRU Small Groups, Target Areas, and Contact information
Version: 1.0
Author: Jason P Rahman (jprahman93@gmail.com, rahmanj@purdue.edu)
*/


// Check if this function exists to see if we are being invoked as a plugin
// in wordpress context, otherwise we need to bailout and not output anything
if (!function_exists('add_action')) {
    exit(1);
}

// Export the path to the plugin to allow themes to access plugin files
define('PURDUE_CRU_PLUGIN_PATH', plugin_dir_path(__FILE__) );

require_once("CRU_Small_Groups_Module.php");
require_once("CRU_Admin_Module.php");
require_once("CRU_Target_Areas_Module.php");
require_once("CRU_Contacts_Module.php");
require_once("CRU_Action_Dispatcher.php");
require_once("CRU_Utils.php");

/**
 * Set the timezone for eastern time
 */
date_default_timezone_set('America/Indianapolis');

global $cru_db_version;
$cru_db_version = "1.0";

$dispatcher = new CRU_Action_Dispatcher();
$small_groups_module = new CRU_Small_Groups_Module($dispatcher);
$target_areas_module = new CRU_Target_Areas_Module($dispatcher);
$contacts_module = new CRU_Contacts_Module($dispatcher);
$admin_module = new CRU_Admin_Module($dispatcher);

$modules = array($dispatcher,
                $small_groups_module,
                $target_areas_module,
                $contacts_module,
                $admin_module);

$CRU_plugin = new CRU_Plugin($modules);

/**
 * Primary class for the Purdue CRU Website Plugin
 *
 * @author Jason P Rahman (jprahman93@gmail.com, rahmanj@purdue.edu)
 */
class CRU_Plugin {

    /**
     *
     * Perform initialization such as adding action hooks
     *
     */
    public function __construct($modules) {
        $this->_capability = 'edit_user';
        $this->modules = $modules;

        // Add admin menu pages
        if (is_array($this->modules)) {
            foreach ($this->modules as $module) {
                if (method_exists($module, 'register_module')) {
                    $module->register_module();
                }
            }
        }

        // Add target area AJAX handlers
        add_action('wp_ajax_add_target_area', array($this, 'cru_add_target_area'));
        add_action('wp_ajax_delete_target_area', array($this, 'cru_delete_target_area'));
        add_action('wp_ajax_edit_target_area', array($this, 'cru_edit_target_area'));

        // Add affiliation AJAX handlers
        add_action('wp_ajax_add_affiliation', array($this, 'cru_add_affiliation'));
        add_action('wp_ajax_delete_affiliation', array($this, 'cru_delete_affiliation'));
        
        // Add contact AJAX handlers
        add_action('wp_ajax_edit_contact', array($this, 'cru_edit_contact'));

        // Add small group AJAX handlers
        add_action('wp_ajax_add_small_group', array($this, 'cru_add_small_group'));
        add_action('wp_ajax_delete_small_group', array($this, 'cru_delete_small_group'));
        add_action('wp_ajax_edit_small_group', array($this, 'cru_edit_small_group'));

        // Enqueue scripts and style sheets
        add_action('admin_print_styles', array($this, 'cru_add_admin_styles'));

        // Register (de)activation hooks
        register_activation_hook(__FILE__, array($this, 'cru_install_plugin'));
        register_deactivation_hook(__FILE__, array($this, 'cru_uninstall_plugin'));
    } // public function __construct()

    /**
     *
     * Variable to store modules in
     *
     */
    public $modules;

    /**
     *
     * Perform one time initialization for the plugin
     *
     */
    public function cru_install_plugin() {

        // Install each module if possible
        if (is_array($this->modules)) {
            foreach ($this->modules as $module) {
                if (method_exists($module, 'install_module')) {
                    $module->install_module();
                }
            }
        }

        add_role("cru_staff", "CRU Staff");
        add_role("cru_student", "CRU Student");

        // Init each role with the correct CRU permissions
        $role = get_role("cru_staff");
        if ($role !== NULL) {
            $role->add_cap("add_target_areas");
            $role->add_cap("edit_target_areas");
            $role->add_cap("delete_target_areas");
            $role->add_cap("add_small_groups");
            $role->add_cap("edit_small_groups");
            $role->add_cap("delete_small_groups");
            $role->add_cap("edit_cru_contacts");
            $role->add_cap("edit_cru_options");
            $role->add_cap("cru_admin");
            $role->add_cap("read");
        }
        
        $role = get_role("cru_student");
        if ($role !== NULL) {
            $role->add_cap("add_small_groups");
            $role->add_cap("edit_small_groups");
            $role->add_cap("delete_small_groups");
            $role->add_cap("edit_cru_contacts");
            $role->add_cap("read");
        }

        $role = get_role("administrator");
        if ($role !== NULL) {
            $role->add_cap("add_target_areas");
            $role->add_cap("edit_target_areas");
            $role->add_cap("delete_target_areas");
            $role->add_cap("add_small_groups");
            $role->add_cap("edit_small_groups");
            $role->add_cap("delete_small_groups");
            $role->add_cap("edit_cru_contacts");
            $role->add_cap("edit_cru_options");
            $role->add_cap("cru_admin");
        }

        // Install or update the database
        $this->cru_install_database();

    } // public function cru_install_plugin()


    /**
     *
     * Run a query through dbDelta to update/create the database
     *
     */
    public function cru_install_database() {
        global $wpdb;
        global $cru_db_version;

        $target_areas_table = $wpdb->prefix . CRU_Utils::_target_areas_table;
        $small_groups_table = $wpdb->prefix . CRU_Utils::_small_groups_table;
        $area_contacts_table = $wpdb->prefix . CRU_Utils::_area_contacts_table;
        $providers_table = $wpdb->prefix . CRU_Utils::_provider_table;
        
        // Define SQL to create database tables
        // Presently dbDelta throws a hissy fit over the foreign keys
        $sql = "CREATE TABLE $target_areas_table (
        area_id mediumint(9) NOT NULL AUTO_INCREMENT,
        area_name char(64) NOT NULL,
        PRIMARY KEY  (area_id)
        );
        CREATE TABLE $small_groups_table (
        group_id mediumint(9) NOT NULL AUTO_INCREMENT,
        area_id mediumint(9) NOT NULL,
        contact_id bigint(20) unsigned NOT NULL,
        day char(10) NOT NULL,
        time char(10) NOT NULL,
        location varchar(512) NOT NULL,
        men tinyint(2) NOT NULL,
        women tinyint(2) NOT NULL,
        PRIMARY KEY  (group_id)," .
        /*FOREIGN KEY  (area_id) REFERENCES $target_areas_table(area_id),
        FOREIGN KEY  (contact_id) REFERENCES $wpdb->users(ID)*/
        ");
        CREATE TABLE $area_contacts_table (
        area_id mediumint(9) NOT NULL,
        contact_id bigint(20) unsigned NOT NULL,
        affiliation_type tinyint(3) NOT NULL," .
        /*FOREIGN KEY  (area_id) REFERENCES $target_area_table(area_id),
        FOREIGN KEY  (contact_id) REFERENCES $wpdb->users(ID),*/
        "PRIMARY KEY  (area_id,contact_id,affiliation_type)
        );
        CREATE TABLE $providers_table (
        provider_id tinyint(5) NOT NULL AUTO_INCREMENT,
        provider_name char(50) NOT NULL,
        provider_gateway char(125) NOT NULL,
        PRIMARY KEY  (provider_id)
        );";
            

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

        dbDelta($sql);

        // Populate the providers table with a pre-selected list of providers
        $wpdb->insert($providers_table,
            array('provider_id' => 1, 'provider_name' => "AT&T", 'provider_gateway' => 'txt.att.net'));
        $wpdb->insert($providers_table,
            array('provider_id' => 2, 'provider_name' => "Verizon", 'provider_gateway' => 'vtext.com'));
        $wpdb->insert($providers_table,
            array('provider_id' => 3, 'provider_name' => "Sprint", 'provider_gateway' => "messaging.sprintpcs.com"));
        $wpdb->insert($providers_table,
            array('provider_id' => 4, 'provider_name' => "T-Mobile", 'provider_gateway' => "tmomail.net"));
        $wpdb->insert($providers_table,
            array('provider_id' => 5, 'provider_name' => "Straight Talk", 'provider_gateway' => "vtext.com"));
        $wpdb->insert($providers_table,
            array('provider_id' => 6, 'provider_name' => "TracFone", 'provider_gateway' => "mmst5.tracfone.com"));
        
        add_option("cru_db_version", $cru_db_version);
    } // public function cru_install_database()


    // TODO Consider implementing this
    
    /** 
     *
     *
     *
     */
    public function cru_uninstall_plugin() {

    }
 
    /**
     *
     * Inject plugin admin stylesheets into the header
     *
     */
    public function cru_add_admin_styles() {
        wp_register_style("cru_admin_style", plugins_url("PurdueCRU/css/cru_admin_style.css"));
        wp_enqueue_style("cru_admin_style");
    }
}
?>
